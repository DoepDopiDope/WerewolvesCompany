### [0.1.1]

Add missing files

### [0.1.0]

First release. Missing the possibility to change the enabled roles within the ship.