### [0.1.4]

Added the roles setup in the ship terminal

Re-Enabled the hold-P (5s) keybind to distribute roles. This is to be used in case the default roles distribution fails.

### [0.1.3]

Added LICENSE

Notified in README that hold-P keybind is disabled

### [0.1.2]

Disable the hold-P keybind, it's giving errors

### [0.1.1]

Add missing files

### [0.1.0]

First release. Missing the possibility to change the enabled roles within the ship.