### [0.2.1]

Centered RoleHUD

Fixed an issue where the mod would prevent interactions texts from displaying when facing interactable objects.

### [0.2.0]

Huge performance improvements.

Changed default config values.

Added debug commands in the terminal.

Changed default keybinds.

Added cooldowns to the top-screen HUD.

### [0.1.6]

Fixed a bug where all actions would target the host instead of the desired target. It worked in local tests, but I realized the bug when trying the mod online with friends... Sorry!

Fixed a bug where the mod would prevent Hover-Tips from displaying

### [0.1.5]

Added 'wc' alias for 'werewolves' in the terminal.

Fixed bugs with the terminal interface.

### [0.1.4]

Added a default roles setup list, including all roles.

Also disabled the debug logs, which I forgot to do in 0.1.4.

### [0.1.4]

Added the roles setup in the ship terminal

Re-Enabled the hold-P (5s) keybind to distribute roles. This is to be used in case the default roles distribution fails.

### [0.1.3]

Added LICENSE

Notified in README that hold-P keybind is disabled

### [0.1.2]

Disable the hold-P keybind, it's giving errors

### [0.1.1]

Add missing files

### [0.1.0]

First release. Missing the possibility to change the enabled roles within the ship.